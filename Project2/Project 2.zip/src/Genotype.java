public class Genotype {
    PixelEdge[] pixelEdges;

    public Genotype(PixelEdge[] pixelEdges){
        this.pixelEdges = pixelEdges;
    }
}
